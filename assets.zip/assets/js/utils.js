var Utils = {

    isNumeric : function(value){
        return !isNaN(parseFloat(value)) && isFinite(value);
    }

};